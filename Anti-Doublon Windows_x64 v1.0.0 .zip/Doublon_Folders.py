import os
import hashlib
from colorama import init, Fore, Style
import sys
import time
from tqdm import tqdm

init()

ASCII_ART = f"""
{Fore.CYAN}
___________.__        .__    .___        _____               
\_   _____/|  |  __ __|__| __| _/__.__._/ ____\____  ___  ___
 |    __)  |  | |  |  \  |/ __ <   |  |\   __\\__  \ \  \/  /
 |     \   |  |_|  |  /  / /_/ |\___  | |  |   / __ \_>    < 
 \___  /   |____/____/|__\____ |/ ____| |__|  (____  /__/\_ \                                    
     \/                       \/\/                 \/      \/                                                                   

{Style.RESET_ALL}
🔍 {Fore.YELLOW}Duplicate File Manager{Style.RESET_ALL} 🗑️
"""

def calculate_hash(filepath):
    """Calcule le hash MD5 d'un fichier en lisant par blocs pour réduire l'utilisation mémoire"""
    hasher = hashlib.md5()
    with open(filepath, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            hasher.update(chunk)
    return hasher.hexdigest()


def scan_folder(folder_path):
    """Scan un dossier et trouve les doublons avec une barre de progression"""
    files_dict = {}
    duplicates = 0
    all_files = []

    for root, _, files in os.walk(folder_path):
        for filename in files:
            filepath = os.path.join(root, filename)
            all_files.append(filepath)

    start_time = time.time()

    for filepath in tqdm(all_files, desc="Scanning files", ncols=100):
        try:
            file_hash = calculate_hash(filepath)
            if file_hash in files_dict:
                files_dict[file_hash].append(filepath)
                duplicates += 1
            else:
                files_dict[file_hash] = [filepath]
        except (IOError, OSError):
            continue

    elapsed_time = time.time() - start_time
    print(f"\n⏱ Temps estimé : {round(elapsed_time, 2)} secondes")
    return files_dict, duplicates

def delete_duplicates(files_dict):
    """Supprime tous les fichiers dupliqués"""
    deleted = 0
    for file_list in files_dict.values():
        if len(file_list) > 1:
            for filepath in file_list[1:]: 
                try:
                    os.remove(filepath)
                    deleted += 1
                except:
                    continue
    return deleted

def clear_screen():
    """Efface l'écran du CMD"""
    os.system('cls' if os.name == 'nt' else 'clear')

def print_menu():
    """Affiche le menu principal"""
    clear_screen()
    print(ASCII_ART)
    print(f"{Fore.CYAN}1) 🔍 Scan files in a folder{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}   # {duplicates_count} doublon(s) found{Style.RESET_ALL}" if 'duplicates_count' in globals() else "")
    print(f"{Fore.MAGENTA}2) 🗑️ Delete all doublon{Style.RESET_ALL}")
    print(f"{Fore.GREEN}   Successfully deleted {deleted_files} files{Style.RESET_ALL}" if 'deleted_files' in globals() else "")
    print(f"{Fore.RED}3) ❌ Close{Style.RESET_ALL}")
    print("\n" + "═" * 50)

files_dict = {}
duplicates_count = 0
deleted_files = 0

if os.name == 'nt':
    os.system("title File Remover by Fluidyfax🗑️")

def main():
    global files_dict, duplicates_count, deleted_files

    while True:
        print_menu()
        choice = input(f"{Fore.WHITE}👉 Select an option (1-3): {Style.RESET_ALL}")

        if choice == "1":
            folder_path = input("\nEnter folder path to scan: ")
            if os.path.isdir(folder_path):
                files_dict, duplicates_count = scan_folder(folder_path)
                print(f"\n{Fore.YELLOW}🔍 Scan completed! Found {duplicates_count} duplicates.{Style.RESET_ALL}")
                input("\nPress Enter to continue...")
            else:
                print(f"{Fore.RED}❌ Invalid folder path!{Style.RESET_ALL}")
                input("\nPress Enter to continue...")

        elif choice == "2":
            if files_dict:
                deleted_files = delete_duplicates(files_dict)
                print(f"\n{Fore.GREEN}✅ Successfully deleted {deleted_files} duplicate files!{Style.RESET_ALL}")
                duplicates_count = 0  
                input("\nPress Enter to continue...")
            else:
                print(f"{Fore.RED}❌ Please scan a folder first!{Style.RESET_ALL}")
                input("\nPress Enter to continue...")

        elif choice == "3":
            print(f"\n{Fore.RED}👋 Closing Duplicate File Remover...{Style.RESET_ALL}")
            sys.exit()

        else:
            print(f"{Fore.RED}❌ Invalid choice! Please select 1-3.{Style.RESET_ALL}")
            input("\nPress Enter to continue...")

if __name__ == "__main__":
    main()